package Oblig.shapes;

import javafx.scene.shape.Polyline;

public class MyPolyline extends Polyline {
    public MyPolyline(double x, double y, double x2, double y2) {
        super(x, y, x2, y2);
    }

    public void rotateForward() {

    }
}
