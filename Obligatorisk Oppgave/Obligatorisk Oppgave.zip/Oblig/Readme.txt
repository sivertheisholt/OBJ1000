Jeg har brukt json-simple library for å kunne lese json filer i java.
Det ble brukt for å konvertere hex fargekode til et vanlig fargenavn. 
https://github.com/fangyidong/json-simple

Studentnummer: 233518